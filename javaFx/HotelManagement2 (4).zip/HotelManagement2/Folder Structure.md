pom.xml
src/module-info.java
src/application/
├── Main.java
├── application.css
├── controllers/
│   ├── MainController.java
│   ├── RoomController.java
│   └── BookingController.java
├── views/
│   ├── login.fxml
│   ├── rooms.fxml
│   └── booking.fxml
├── models/
│   ├── Booking.java
│   └── Room.java
