pom.xml
src/module-info.java
src/application/
├── Main.java
├── application.css
├── controllers/
│   ├── MainController.java
│   ├── RoomController.java
│   └── BookingController.java
├── views/
│   ├── login.fxml
│   ├── rooms.fxml
│   └── booking.fxml
├── models/
│   ├── Booking.java
│   └── Room.java

Dev notes:
- in admin panel the reservations are not loaded initially but are added to the table itself 25/04/2025 10:19 (save zip 5)
